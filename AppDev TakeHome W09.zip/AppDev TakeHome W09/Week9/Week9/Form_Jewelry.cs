﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9
{
    public partial class Form_Jewelry : Form
    {
        Form_Main formmain;
        public Form_Jewelry()
        {
            InitializeComponent();
        }
        public void FormThis(Form_Main formthis)
        {
            this.formmain = formthis;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Diamond Ring", 4800000);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Nail Ring", 2200000);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Knot Ring", 1900000);
        }
    }
}
