﻿namespace Week9
{
    partial class Form_Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MenuStrip_Menu = new MenuStrip();
            topWearToolStripMenuItem = new ToolStripMenuItem();
            tShirtToolStripMenuItem = new ToolStripMenuItem();
            shirtToolStripMenuItem = new ToolStripMenuItem();
            bottomWearToolStripMenuItem = new ToolStripMenuItem();
            pantsToolStripMenuItem = new ToolStripMenuItem();
            longPantsToolStripMenuItem = new ToolStripMenuItem();
            acceToolStripMenuItem = new ToolStripMenuItem();
            shoesToolStripMenuItem = new ToolStripMenuItem();
            jewelToolStripMenuItem = new ToolStripMenuItem();
            othersToolStripMenuItem = new ToolStripMenuItem();
            Panel_Main = new Panel();
            Dgv_Information = new DataGridView();
            Lbl_SubTotal = new Label();
            Lbl_Total = new Label();
            Tb_SubTotal = new TextBox();
            Tb_Total = new TextBox();
            Btn_Cancel = new Button();
            MenuStrip_Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Dgv_Information).BeginInit();
            SuspendLayout();
            // 
            // MenuStrip_Menu
            // 
            MenuStrip_Menu.ImageScalingSize = new Size(32, 32);
            MenuStrip_Menu.Items.AddRange(new ToolStripItem[] { topWearToolStripMenuItem, bottomWearToolStripMenuItem, acceToolStripMenuItem, othersToolStripMenuItem });
            MenuStrip_Menu.Location = new Point(0, 0);
            MenuStrip_Menu.Name = "MenuStrip_Menu";
            MenuStrip_Menu.Padding = new Padding(11, 4, 0, 4);
            MenuStrip_Menu.Size = new Size(1764, 44);
            MenuStrip_Menu.TabIndex = 0;
            MenuStrip_Menu.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            topWearToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { tShirtToolStripMenuItem, shirtToolStripMenuItem });
            topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            topWearToolStripMenuItem.Size = new Size(134, 36);
            topWearToolStripMenuItem.Text = "Top Wear";
            topWearToolStripMenuItem.Click += topWearToolStripMenuItem_Click;
            // 
            // tShirtToolStripMenuItem
            // 
            tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            tShirtToolStripMenuItem.Size = new Size(359, 44);
            tShirtToolStripMenuItem.Text = "T-Shirt";
            tShirtToolStripMenuItem.Click += tShirtToolStripMenuItem_Click;
            // 
            // shirtToolStripMenuItem
            // 
            shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            shirtToolStripMenuItem.Size = new Size(359, 44);
            shirtToolStripMenuItem.Text = "Shirt";
            shirtToolStripMenuItem.Click += shirtToolStripMenuItem_Click;
            // 
            // bottomWearToolStripMenuItem
            // 
            bottomWearToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { pantsToolStripMenuItem, longPantsToolStripMenuItem });
            bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            bottomWearToolStripMenuItem.Size = new Size(174, 36);
            bottomWearToolStripMenuItem.Text = "Bottom Wear";
            bottomWearToolStripMenuItem.Click += bottomWearToolStripMenuItem_Click;
            // 
            // pantsToolStripMenuItem
            // 
            pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            pantsToolStripMenuItem.Size = new Size(359, 44);
            pantsToolStripMenuItem.Text = "Pants";
            pantsToolStripMenuItem.Click += pantsToolStripMenuItem_Click;
            // 
            // longPantsToolStripMenuItem
            // 
            longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            longPantsToolStripMenuItem.Size = new Size(359, 44);
            longPantsToolStripMenuItem.Text = "Long Pants";
            longPantsToolStripMenuItem.Click += longPantsToolStripMenuItem_Click;
            // 
            // acceToolStripMenuItem
            // 
            acceToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { shoesToolStripMenuItem, jewelToolStripMenuItem });
            acceToolStripMenuItem.Name = "acceToolStripMenuItem";
            acceToolStripMenuItem.Size = new Size(155, 36);
            acceToolStripMenuItem.Text = "Accessories";
            acceToolStripMenuItem.Click += acceToolStripMenuItem_Click;
            // 
            // shoesToolStripMenuItem
            // 
            shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            shoesToolStripMenuItem.Size = new Size(211, 44);
            shoesToolStripMenuItem.Text = "Shoes";
            shoesToolStripMenuItem.Click += shoesToolStripMenuItem_Click;
            // 
            // jewelToolStripMenuItem
            // 
            jewelToolStripMenuItem.Name = "jewelToolStripMenuItem";
            jewelToolStripMenuItem.Size = new Size(211, 44);
            jewelToolStripMenuItem.Text = "Jewel";
            jewelToolStripMenuItem.Click += jewelToolStripMenuItem_Click;
            // 
            // othersToolStripMenuItem
            // 
            othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            othersToolStripMenuItem.Size = new Size(105, 36);
            othersToolStripMenuItem.Text = "Others";
            othersToolStripMenuItem.Click += othersToolStripMenuItem_Click;
            // 
            // Panel_Main
            // 
            Panel_Main.Location = new Point(0, 58);
            Panel_Main.Margin = new Padding(6, 6, 6, 6);
            Panel_Main.Name = "Panel_Main";
            Panel_Main.Size = new Size(1033, 905);
            Panel_Main.TabIndex = 1;
            // 
            // Dgv_Information
            // 
            Dgv_Information.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Dgv_Information.Location = new Point(1066, 58);
            Dgv_Information.Margin = new Padding(6, 6, 6, 6);
            Dgv_Information.Name = "Dgv_Information";
            Dgv_Information.RowHeadersWidth = 82;
            Dgv_Information.RowTemplate.Height = 25;
            Dgv_Information.Size = new Size(654, 510);
            Dgv_Information.TabIndex = 2;
            Dgv_Information.CellStateChanged += dgv_CellStateChanged;
            Dgv_Information.CellValueChanged += dgv_CellValueChanged;
            Dgv_Information.RowStateChanged += dgv_RowStateChanged;
            Dgv_Information.KeyDown += dgv_KeyDown;
            // 
            // Lbl_SubTotal
            // 
            Lbl_SubTotal.AutoSize = true;
            Lbl_SubTotal.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            Lbl_SubTotal.Location = new Point(1066, 689);
            Lbl_SubTotal.Margin = new Padding(6, 0, 6, 0);
            Lbl_SubTotal.Name = "Lbl_SubTotal";
            Lbl_SubTotal.Size = new Size(201, 57);
            Lbl_SubTotal.TabIndex = 3;
            Lbl_SubTotal.Text = "Sub-Total";
            // 
            // Lbl_Total
            // 
            Lbl_Total.AutoSize = true;
            Lbl_Total.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            Lbl_Total.Location = new Point(1154, 791);
            Lbl_Total.Margin = new Padding(6, 0, 6, 0);
            Lbl_Total.Name = "Lbl_Total";
            Lbl_Total.Size = new Size(113, 57);
            Lbl_Total.TabIndex = 4;
            Lbl_Total.Text = "Total";
            // 
            // Tb_SubTotal
            // 
            Tb_SubTotal.Location = new Point(1279, 706);
            Tb_SubTotal.Margin = new Padding(6, 6, 6, 6);
            Tb_SubTotal.Name = "Tb_SubTotal";
            Tb_SubTotal.Size = new Size(427, 39);
            Tb_SubTotal.TabIndex = 5;
            // 
            // Tb_Total
            // 
            Tb_Total.Location = new Point(1279, 808);
            Tb_Total.Margin = new Padding(6, 6, 6, 6);
            Tb_Total.Name = "Tb_Total";
            Tb_Total.Size = new Size(427, 39);
            Tb_Total.TabIndex = 6;
            // 
            // Btn_Cancel
            // 
            Btn_Cancel.Location = new Point(1066, 580);
            Btn_Cancel.Margin = new Padding(6, 6, 6, 6);
            Btn_Cancel.Name = "Btn_Cancel";
            Btn_Cancel.Size = new Size(98, 49);
            Btn_Cancel.TabIndex = 7;
            Btn_Cancel.Text = "Cancel";
            Btn_Cancel.UseVisualStyleBackColor = true;
            Btn_Cancel.Click += button1_Click;
            // 
            // Form_Main
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1764, 960);
            Controls.Add(Btn_Cancel);
            Controls.Add(Tb_Total);
            Controls.Add(Tb_SubTotal);
            Controls.Add(Lbl_Total);
            Controls.Add(Lbl_SubTotal);
            Controls.Add(Dgv_Information);
            Controls.Add(Panel_Main);
            Controls.Add(MenuStrip_Menu);
            MainMenuStrip = MenuStrip_Menu;
            Margin = new Padding(6, 6, 6, 6);
            Name = "Form_Main";
            Text = "Form1";
            MenuStrip_Menu.ResumeLayout(false);
            MenuStrip_Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Dgv_Information).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip MenuStrip_Menu;
        private ToolStripMenuItem topWearToolStripMenuItem;
        private ToolStripMenuItem bottomWearToolStripMenuItem;
        private ToolStripMenuItem acceToolStripMenuItem;
        private ToolStripMenuItem othersToolStripMenuItem;
        private Panel Panel_Main;
        private DataGridView Dgv_Information;
        private Label Lbl_SubTotal;
        private Label Lbl_Total;
        private TextBox Tb_SubTotal;
        private TextBox Tb_Total;
        private Button Btn_Cancel;
        private ToolStripMenuItem tShirtToolStripMenuItem;
        private ToolStripMenuItem shirtToolStripMenuItem;
        private ToolStripMenuItem pantsToolStripMenuItem;
        private ToolStripMenuItem longPantsToolStripMenuItem;
        private ToolStripMenuItem shoesToolStripMenuItem;
        private ToolStripMenuItem jewelToolStripMenuItem;
    }
}