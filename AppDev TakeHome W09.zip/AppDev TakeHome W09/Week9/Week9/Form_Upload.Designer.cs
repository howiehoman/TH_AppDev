﻿namespace Week9
{
    partial class Form_Upload
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Pb_Upload = new PictureBox();
            Lbl_UploadImg = new Label();
            Btn_UploadImg = new Button();
            label1 = new Label();
            Tb_ItemName = new TextBox();
            Tb_ItemCost = new TextBox();
            label2 = new Label();
            Btn_AddCart = new Button();
            Btn_ClearImg = new Button();
            ((System.ComponentModel.ISupportInitialize)Pb_Upload).BeginInit();
            SuspendLayout();
            // 
            // Pb_Upload
            // 
            Pb_Upload.BorderStyle = BorderStyle.FixedSingle;
            Pb_Upload.Location = new Point(308, 181);
            Pb_Upload.Margin = new Padding(6);
            Pb_Upload.Name = "Pb_Upload";
            Pb_Upload.Size = new Size(253, 503);
            Pb_Upload.SizeMode = PictureBoxSizeMode.StretchImage;
            Pb_Upload.TabIndex = 4;
            Pb_Upload.TabStop = false;
            Pb_Upload.Click += pictureBox2_Click;
            // 
            // Lbl_UploadImg
            // 
            Lbl_UploadImg.AutoSize = true;
            Lbl_UploadImg.Location = new Point(308, 51);
            Lbl_UploadImg.Margin = new Padding(6, 0, 6, 0);
            Lbl_UploadImg.Name = "Lbl_UploadImg";
            Lbl_UploadImg.Size = new Size(163, 32);
            Lbl_UploadImg.TabIndex = 19;
            Lbl_UploadImg.Text = "Upload Image";
            Lbl_UploadImg.Click += label4_Click;
            // 
            // Btn_UploadImg
            // 
            Btn_UploadImg.Location = new Point(470, 43);
            Btn_UploadImg.Margin = new Padding(6);
            Btn_UploadImg.Name = "Btn_UploadImg";
            Btn_UploadImg.Size = new Size(171, 49);
            Btn_UploadImg.TabIndex = 22;
            Btn_UploadImg.Text = "Upload";
            Btn_UploadImg.UseVisualStyleBackColor = true;
            Btn_UploadImg.Click += Btn_UploadImg_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(591, 181);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(133, 32);
            label1.TabIndex = 23;
            label1.Text = "Item Name";
            // 
            // Tb_ItemName
            // 
            Tb_ItemName.Enabled = false;
            Tb_ItemName.Location = new Point(591, 220);
            Tb_ItemName.Margin = new Padding(6);
            Tb_ItemName.Name = "Tb_ItemName";
            Tb_ItemName.Size = new Size(182, 39);
            Tb_ItemName.TabIndex = 24;
            Tb_ItemName.TextChanged += Tb_ItemName_TextChanged;
            // 
            // Tb_ItemCost
            // 
            Tb_ItemCost.Enabled = false;
            Tb_ItemCost.Location = new Point(591, 337);
            Tb_ItemCost.Margin = new Padding(6);
            Tb_ItemCost.Name = "Tb_ItemCost";
            Tb_ItemCost.Size = new Size(182, 39);
            Tb_ItemCost.TabIndex = 26;
            Tb_ItemCost.TextChanged += Tb_ItemCost_TextChanged;
            Tb_ItemCost.KeyPress += Tb_ItemCost_KeyPress;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(591, 299);
            label2.Margin = new Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new Size(116, 32);
            label2.TabIndex = 25;
            label2.Text = "Item Cost";
            // 
            // Btn_AddCart
            // 
            Btn_AddCart.Enabled = false;
            Btn_AddCart.Location = new Point(591, 435);
            Btn_AddCart.Margin = new Padding(6);
            Btn_AddCart.Name = "Btn_AddCart";
            Btn_AddCart.Size = new Size(171, 49);
            Btn_AddCart.TabIndex = 27;
            Btn_AddCart.Text = "Add to Cart";
            Btn_AddCart.UseVisualStyleBackColor = true;
            Btn_AddCart.Click += Btn_AddCart_Click;
            // 
            // Btn_ClearImg
            // 
            Btn_ClearImg.Location = new Point(308, 122);
            Btn_ClearImg.Margin = new Padding(6);
            Btn_ClearImg.Name = "Btn_ClearImg";
            Btn_ClearImg.Size = new Size(150, 47);
            Btn_ClearImg.TabIndex = 28;
            Btn_ClearImg.Text = "Clear Image";
            Btn_ClearImg.UseVisualStyleBackColor = true;
            Btn_ClearImg.Click += Btn_ClearImg_Click;
            // 
            // Form_Upload
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1033, 905);
            Controls.Add(Btn_ClearImg);
            Controls.Add(Btn_AddCart);
            Controls.Add(Tb_ItemCost);
            Controls.Add(label2);
            Controls.Add(Tb_ItemName);
            Controls.Add(label1);
            Controls.Add(Btn_UploadImg);
            Controls.Add(Lbl_UploadImg);
            Controls.Add(Pb_Upload);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(6);
            Name = "Form_Upload";
            Text = "FormOthers";
            ((System.ComponentModel.ISupportInitialize)Pb_Upload).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox Pb_Upload;
        private Label Lbl_UploadImg;
        private Button Btn_UploadImg;
        private Label label1;
        private TextBox Tb_ItemName;
        private TextBox Tb_ItemCost;
        private Label label2;
        private Button Btn_AddCart;
        private Button Btn_ClearImg;
    }
}