﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9
{
    public partial class Form_Shirt : Form
    {
        Form_Main formmain;
        public Form_Shirt()
        {
            InitializeComponent();
        }
        public void FormThis(Form_Main formthis)
        {
            this.formmain = formthis;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("White Shirt", 80000);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Black Shirt", 100000);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            formmain.ItemAdd("Beige Shirt", 120000);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
