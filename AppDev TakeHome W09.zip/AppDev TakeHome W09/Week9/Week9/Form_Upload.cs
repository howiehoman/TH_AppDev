﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9
{

    public partial class Form_Upload : Form
    {
        Form_Main formmain;
        public Form_Upload()
        {
            InitializeComponent();
        }
        public void FormThis(Form_Main formthis)
        {
            this.formmain = formthis;
        }

        private void Btn_AddCart_Click(object sender, EventArgs e)
        {
            if (Tb_ItemName.Text != "" && Tb_ItemCost.Text != "")
            {
                formmain.ItemAdd(Tb_ItemName.Text, Convert.ToInt32(Tb_ItemCost.Text));
            }
            else
            {
                MessageBox.Show("Please Fill Everything");
            }
        }

        private void Btn_UploadImg_Click(object sender, EventArgs e)
        {
            string imagedirectory = "";
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "jpg files(.*jpg)|*.jpg| PNG files(.*png)|*.png| All Files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imagedirectory = dialog.FileName;
                Pb_Upload.ImageLocation = imagedirectory;
            }


            Tb_ItemName.Enabled = true;
            Tb_ItemCost.Enabled = true;
            Btn_AddCart.Enabled = true;

        }

        private void Tb_ItemCost_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void Btn_ClearImg_Click(object sender, EventArgs e)
        {
            Pb_Upload.Image = null;
            Tb_ItemName.Enabled = false;
            Tb_ItemCost.Enabled = false;
            Btn_AddCart.Enabled = false;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Tb_ItemName_TextChanged(object sender, EventArgs e)
        {

        }

        private void Tb_ItemCost_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
