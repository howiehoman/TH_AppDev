using System.Data;
using System.Diagnostics;

namespace ADTakeHomeW5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DataTable DTKeepProduct = new DataTable();
        DataTable DTShowProduct = new DataTable();
        DataTable DTCategory = new DataTable();

        public List<string> ListProductID = new List<string>();
        public List<string> ListProductName = new List<string>();
        public List<Int64> ListProductPrice = new List<Int64>();
        public List<Int32> ListProductStock = new List<Int32>();
        public List<string> ListProductCategoryID = new List<string>();

        public List<string> ListCategoryID = new List<string>();
        public List<string> ListCategoryName = new List<string>();

        public bool Check = true;
        public int NewProductID;
        public string SelectedCell;
        public string FirstWord;
        string IDNum0 = "00";
        private void Form1_Load(object sender, EventArgs e)
        {
            DTKeepProduct.Columns.Add("ID Product");
            DTKeepProduct.Columns.Add("Nama Product");
            DTKeepProduct.Columns.Add("Harga");
            DTKeepProduct.Columns.Add("Stock");
            DTKeepProduct.Columns.Add("ID Category");

            DTShowProduct.Columns.Add("ID Product");
            DTShowProduct.Columns.Add("Nama Product");
            DTShowProduct.Columns.Add("Harga");
            DTShowProduct.Columns.Add("Stock");
            DTShowProduct.Columns.Add("ID Category");

            DTCategory.Columns.Add("ID Category");
            DTCategory.Columns.Add("Nama Category");

            ListCategoryID.Add("C1");
            ListCategoryID.Add("C2");
            ListCategoryID.Add("C3");
            ListCategoryID.Add("C4");
            ListCategoryID.Add("C5");
            ListCategoryName.Add("Jas");
            ListCategoryName.Add("T-Shirt");
            ListCategoryName.Add("Rok");
            ListCategoryName.Add("Celana");
            ListCategoryName.Add("Cawat");

            ListProductID.Add("J001");
            ListProductID.Add("T001");
            ListProductID.Add("T002");
            ListProductID.Add("R001");
            ListProductID.Add("J002");
            ListProductID.Add("C001");
            ListProductID.Add("C002");
            ListProductID.Add("R002");
            ListProductName.Add("Jas Hitam");
            ListProductName.Add("T-Shirt Blackpink");
            ListProductName.Add("T-Shirt Obsessive");
            ListProductName.Add("Rok Mini");
            ListProductName.Add("Jeans Biru");
            ListProductName.Add("Celana Pendek Coklat");
            ListProductName.Add("Cawat Blink-blink");
            ListProductName.Add("Rocca Shirt");
            ListProductPrice.Add(100000);
            ListProductPrice.Add(70000);
            ListProductPrice.Add(75000);
            ListProductPrice.Add(82000);
            ListProductPrice.Add(90000);
            ListProductPrice.Add(60000);
            ListProductPrice.Add(1000000);
            ListProductPrice.Add(50000);
            ListProductStock.Add(10);
            ListProductStock.Add(20);
            ListProductStock.Add(16);
            ListProductStock.Add(26);
            ListProductStock.Add(5);
            ListProductStock.Add(11);
            ListProductStock.Add(1);
            ListProductStock.Add(8);
            ListProductCategoryID.Add("C1");
            ListProductCategoryID.Add("C2");
            ListProductCategoryID.Add("C2");
            ListProductCategoryID.Add("C3");
            ListProductCategoryID.Add("C4");
            ListProductCategoryID.Add("C4");
            ListProductCategoryID.Add("C5");
            ListProductCategoryID.Add("C2");

            for (int i = 0; i < ListCategoryID.Count; i++)
            {
                DTCategory.Rows.Add(ListCategoryID[i], ListCategoryName[i]);
                Cbox_ProductCategory.Items.Add(ListCategoryName[i]);
                Cbox_Filter.Items.Add(ListCategoryName[i]);
            }
            for (int i = 0; i < ListProductCategoryID.Count; i++)
            {

                DTKeepProduct.Rows.Add(ListProductID[i], ListProductName[i], ListProductPrice[i], ListProductStock[i], ListProductCategoryID[i]);
            }

            Dgv_Category.DataSource = DTCategory;
            Dgv_Product.DataSource = DTKeepProduct;
            Dgv_Category.ClearSelection();
            Dgv_Product.ClearSelection();
            Dgv_Category.CurrentCell = null;
            Dgv_Product.CurrentCell = null;
        }


        private void Btn_AddProduct_Click(object sender, EventArgs e)
        {
            if (Tb_ProductName.Text == "" && Tb_ProductPrice.Text == "" && Tb_ProductStock.Text == "" && Cbox_ProductCategory.SelectedValue == null)
            {
                MessageBox.Show("Fill all of the required fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                FirstWord = Tb_ProductName.Text.Substring(0, 1).ToUpper();

                for (int i = 0; i < ListProductID.Count; i++)
                {
                    if (Tb_ProductName.Text == ListProductName[i])
                    {
                        Check = false;
                    }

                }

                for (int i = 0; i < ListProductID.Count; i++)
                {
                    if (Tb_ProductName.Text.Substring(0, 1).ToUpper() == ListProductID[i].Substring(0, 1).ToUpper())
                    {
                        NewProductID = Convert.ToInt32(ListProductID[i].Substring(1)) + 1;
                    }
                }
                if (NewProductID > 99)
                {
                    IDNum0 = "";
                }
                else if (NewProductID > 9)
                {
                    IDNum0 = "0";
                }

                ListProductID.Add(Tb_ProductName.Text.Substring(0, 1).ToUpper() + IDNum0 + NewProductID);
                ListProductName.Add(Tb_ProductName.Text);
                ListProductPrice.Add(Convert.ToInt64(Tb_ProductPrice.Text));
                ListProductStock.Add(Convert.ToInt32(Tb_ProductStock.Text));
                ListProductCategoryID.Add(ListCategoryID[Cbox_ProductCategory.SelectedIndex]);

                DTKeepProduct.Rows.Clear();
                for (int i = 0; i < ListProductName.Count; i++)
                {
                    DTKeepProduct.Rows.Add(ListProductID[i], ListProductName[i], ListProductPrice[i], ListProductStock[i], ListProductCategoryID[i]);
                }

                Tb_ProductName.Text = null;
                Tb_ProductPrice.Text = null;
                Tb_ProductStock.Text = null;
                Cbox_ProductCategory.Text = null;

            }
        }
        private void Btn_EditProduct_Click(object sender, EventArgs e)
        {
            if (Dgv_Product.CurrentCell == null)
            {
                MessageBox.Show("You Need To Select First", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (Tb_ProductName.Text == "" || Tb_ProductPrice.Text == "" || Tb_ProductStock.Text == "" || Cbox_ProductCategory.Text == "")
                {
                    MessageBox.Show("Please fill all the required fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    for (int i = 0; i < ListProductID.Count; i++)
                    {
                        if (SelectedCell == ListProductID[i])
                        {
                            ListProductName[i] = Tb_ProductName.Text;
                            ListProductPrice[i] = Convert.ToInt64(Tb_ProductPrice.Text);
                            ListProductStock[i] = Convert.ToInt32(Tb_ProductStock.Text);
                            ListProductCategoryID[i] = ListCategoryID[Cbox_ProductCategory.SelectedIndex];

                            if (Convert.ToInt32(Tb_ProductStock.Text) == 0)
                            {
                                ListProductID.RemoveAt(i);
                                ListProductName.RemoveAt(i);
                                ListProductPrice.RemoveAt(i);
                                ListProductStock.RemoveAt(i);
                                ListProductCategoryID.RemoveAt(i);

                            }
                            Tb_ProductName.Text = null;
                            Tb_ProductPrice.Text = null;
                            Tb_ProductStock.Text = null;
                            Cbox_ProductCategory.Text = null;

                            DTKeepProduct.Rows.Clear();
                            for (int j = 0; j < ListProductName.Count; j++)
                            {
                                DTKeepProduct.Rows.Add(ListProductID[j], ListProductName[j], ListProductPrice[j], ListProductStock[j], ListProductCategoryID[j]);
                            }
                        }
                    }

                }
            }
            Dgv_Product.ClearSelection();
            Dgv_Product.CurrentCell = null;
        }

        private void Btn_RemoveProduct_Click(object sender, EventArgs e)
        {
            if (Dgv_Product.CurrentCell == null)
            {
                MessageBox.Show("You Need To Select First", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                for (int i = 0; i < ListProductID.Count; i++)
                {
                    if (SelectedCell == ListProductID[i])
                    {
                        ListProductID.RemoveAt(i);
                        ListProductName.RemoveAt(i);
                        ListProductPrice.RemoveAt(i);
                        ListProductStock.RemoveAt(i);
                        ListProductCategoryID.RemoveAt(i);
                        Tb_ProductName.Text = null;
                        Tb_ProductPrice.Text = null;
                        Tb_ProductStock.Text = null;
                        Cbox_ProductCategory.Text = null;

                        DTKeepProduct.Rows.Clear();
                        for (int j = 0; j < ListProductName.Count; j++)
                        {
                            DTKeepProduct.Rows.Add(ListProductID[j], ListProductName[j], ListProductPrice[j], ListProductStock[j], ListProductCategoryID[j]);
                        }

                        Dgv_Product.ClearSelection();
                        Dgv_Product.CurrentCell = null;
                        SelectedCell = "";
                    }
                }
            }
        }

        private void Btn_AddCategory_Click(object sender, EventArgs e)
        {
            string tampungan = "";
            Check = true;



            if (Tb_CategoryName.Text == "")
            {
                MessageBox.Show("Please fill all the required fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                for (int i = 0; i < ListCategoryID.Count; i++)
                {
                    tampungan = ListCategoryID[i].Substring(1);
                }
                string categoryname = Tb_CategoryName.Text;
                string categoryID = "C" + (Convert.ToInt32(tampungan) + 1);

                for (int i = 0; i < ListCategoryID.Count; i++)
                {
                    if (categoryname == ListCategoryName[i])
                    {
                        Check = false;
                    }

                }
                if (Check == false)
                {
                    MessageBox.Show("Category name already exist", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DTCategory.Rows.Add(categoryID, categoryname);
                    ListCategoryID.Add("C" + Convert.ToInt32(tampungan) + 1);
                    ListCategoryName.Add(Tb_CategoryName.Text);

                    Cbox_Filter.Items.Clear();
                    for (int i = 0; i < ListCategoryName.Count; i++)
                    {
                        Cbox_Filter.Items.Add(ListCategoryName[i]);
                    }

                    Cbox_ProductCategory.Items.Clear();
                    for (int i = 0; i < ListCategoryName.Count; i++)
                    {
                        Cbox_ProductCategory.Items.Add(ListCategoryName[i]);
                    }
                }
                Tb_CategoryName.Clear();
            }
        }

        private void Btn_RemoveCategory_Click(object sender, EventArgs e)
        {
            if (Dgv_Category.CurrentCell == null)
            {
                MessageBox.Show("You Need To Select First", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string selecteditem = ListCategoryID[Dgv_Category.CurrentCell.RowIndex];
                ListCategoryID.RemoveAt(Dgv_Category.CurrentCell.RowIndex);
                ListCategoryName.RemoveAt(Dgv_Category.CurrentCell.RowIndex);
                DTCategory.Rows.RemoveAt(Dgv_Category.CurrentCell.RowIndex);

                for (int i = ListProductCategoryID.Count - 1; i >= 0; i--)
                {
                    if (selecteditem == ListProductCategoryID[i])
                    {
                        DTKeepProduct.Rows.RemoveAt((int)i);
                        ListProductCategoryID.RemoveAt(i);
                        ListProductName.RemoveAt(i);
                        ListProductPrice.RemoveAt(i);
                        ListProductStock.RemoveAt(i);
                        ListProductID.RemoveAt(i);

                    }
                }
                Cbox_Filter.Items.Clear();
                for (int i = 0; i < ListCategoryName.Count; i++)
                {
                    Cbox_Filter.Items.Add(ListCategoryName[i]);
                }

                Cbox_ProductCategory.Items.Clear();
                for (int i = 0; i < ListCategoryName.Count; i++)
                {
                    Cbox_ProductCategory.Items.Add(ListCategoryName[i]);
                }

                Dgv_Category.ClearSelection();
                Dgv_Category.CurrentCell = null;
            }
        }

        private void Tb_ProductPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void Tb_ProductStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void Dgv_Product_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            SelectedCell = Dgv_Product.SelectedCells[0].Value.ToString();
            if (Dgv_Product.CurrentCell == null)
            {
                MessageBox.Show("Select dulu bang", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                for (int i = 0; i < ListProductID.Count; i++)
                {
                    if (SelectedCell == ListProductID[i])
                    {
                        Tb_ProductName.Text = ListProductName[i];
                        Tb_ProductPrice.Text = ListProductPrice[i].ToString();
                        Tb_ProductStock.Text = ListProductStock[i].ToString();
                        foreach (DataRow a in DTCategory.Rows)
                        {
                            if (ListProductCategoryID[i] == a[0].ToString())
                            {
                                Cbox_ProductCategory.Text = a[1].ToString();
                            }
                        }
                    }
                }


            }
        }

        private void Btn_All_Click(object sender, EventArgs e)
        {
            DTKeepProduct.Rows.Clear();
            for (int j = 0; j < ListProductName.Count; j++)
            {
                DTKeepProduct.Rows.Add(ListProductID[j], ListProductName[j], ListProductPrice[j], ListProductStock[j], ListProductCategoryID[j]);
            }

            Cbox_Filter.Text = "";
            Cbox_Filter.Enabled = false;
        }

        private void Btn_Filter_Click(object sender, EventArgs e)
        {
            Cbox_Filter.Enabled = true;

        }

        private void Cbox_Filter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            DTKeepProduct.Rows.Clear();
            for (int i = 0; i < ListProductCategoryID.Count; i++)
            {
                if (ListCategoryID[Cbox_Filter.SelectedIndex] == ListProductCategoryID[i])
                {
                    DTKeepProduct.Rows.Add(ListProductID[i], ListProductName[i], ListProductPrice[i], ListProductStock[i], ListProductCategoryID[i]);
                }
            }
        }
    }
}