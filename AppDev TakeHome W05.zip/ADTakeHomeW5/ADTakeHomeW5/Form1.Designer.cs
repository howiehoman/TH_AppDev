﻿namespace ADTakeHomeW5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Dgv_Product = new DataGridView();
            Dgv_Category = new DataGridView();
            Lbl_Product = new Label();
            Lbl_Category = new Label();
            Btn_Filter = new Button();
            Btn_All = new Button();
            Cbox_Filter = new ComboBox();
            Lbl_ProductDetails = new Label();
            Btn_AddCategory = new Button();
            buttonremovecategory = new Button();
            Lbl_CategoryName = new Label();
            Lbl_ProductName = new Label();
            Tb_ProductName = new TextBox();
            Tb_CategoryName = new TextBox();
            Lbl_ProductCategory = new Label();
            Lbl_ProductPrice = new Label();
            Lbl_ProductStock = new Label();
            Tb_ProductPrice = new TextBox();
            Tb_ProductStock = new TextBox();
            Cbox_ProductCategory = new ComboBox();
            Btn_AddProduct = new Button();
            Btn_RemoveProduct = new Button();
            Btn_EditProduct = new Button();
            ((System.ComponentModel.ISupportInitialize)Dgv_Product).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Dgv_Category).BeginInit();
            SuspendLayout();
            // 
            // Dgv_Product
            // 
            Dgv_Product.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            Dgv_Product.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            Dgv_Product.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Dgv_Product.ColumnHeadersVisible = false;
            Dgv_Product.Location = new Point(16, 65);
            Dgv_Product.Margin = new Padding(4);
            Dgv_Product.Name = "Dgv_Product";
            Dgv_Product.RowHeadersVisible = false;
            Dgv_Product.RowHeadersWidth = 62;
            Dgv_Product.RowTemplate.Height = 33;
            Dgv_Product.Size = new Size(706, 343);
            Dgv_Product.TabIndex = 0;
            // 
            // Dgv_Category
            // 
            Dgv_Category.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            Dgv_Category.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            Dgv_Category.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Dgv_Category.Location = new Point(818, 47);
            Dgv_Category.Margin = new Padding(4);
            Dgv_Category.Name = "Dgv_Category";
            Dgv_Category.RowHeadersWidth = 62;
            Dgv_Category.RowTemplate.Height = 33;
            Dgv_Category.Size = new Size(468, 288);
            Dgv_Category.TabIndex = 1;
            // 
            // Lbl_Product
            // 
            Lbl_Product.AutoSize = true;
            Lbl_Product.Location = new Point(16, 19);
            Lbl_Product.Margin = new Padding(4, 0, 4, 0);
            Lbl_Product.Name = "Lbl_Product";
            Lbl_Product.Size = new Size(96, 32);
            Lbl_Product.TabIndex = 2;
            Lbl_Product.Text = "Product";
            // 
            // Lbl_Category
            // 
            Lbl_Category.AutoSize = true;
            Lbl_Category.Location = new Point(771, 12);
            Lbl_Category.Margin = new Padding(4, 0, 4, 0);
            Lbl_Category.Name = "Lbl_Category";
            Lbl_Category.Size = new Size(110, 32);
            Lbl_Category.TabIndex = 3;
            Lbl_Category.Text = "Category";
            // 
            // Btn_Filter
            // 
            Btn_Filter.Location = new Point(377, 18);
            Btn_Filter.Margin = new Padding(4);
            Btn_Filter.Name = "Btn_Filter";
            Btn_Filter.Size = new Size(146, 41);
            Btn_Filter.TabIndex = 4;
            Btn_Filter.Text = "Filter";
            Btn_Filter.UseVisualStyleBackColor = true;
            // 
            // Btn_All
            // 
            Btn_All.Location = new Point(307, 19);
            Btn_All.Margin = new Padding(4);
            Btn_All.Name = "Btn_All";
            Btn_All.Size = new Size(62, 41);
            Btn_All.TabIndex = 5;
            Btn_All.Text = "All";
            Btn_All.UseVisualStyleBackColor = true;
            // 
            // Cbox_Filter
            // 
            Cbox_Filter.FormattingEnabled = true;
            Cbox_Filter.Location = new Point(530, 19);
            Cbox_Filter.Margin = new Padding(4);
            Cbox_Filter.Name = "Cbox_Filter";
            Cbox_Filter.Size = new Size(190, 40);
            Cbox_Filter.TabIndex = 6;
            // 
            // Lbl_ProductDetails
            // 
            Lbl_ProductDetails.AutoSize = true;
            Lbl_ProductDetails.Location = new Point(27, 412);
            Lbl_ProductDetails.Margin = new Padding(4, 0, 4, 0);
            Lbl_ProductDetails.Name = "Lbl_ProductDetails";
            Lbl_ProductDetails.Size = new Size(86, 32);
            Lbl_ProductDetails.TabIndex = 7;
            Lbl_ProductDetails.Text = "Details";
            // 
            // Btn_AddCategory
            // 
            Btn_AddCategory.BackColor = Color.Lime;
            Btn_AddCategory.Location = new Point(946, 388);
            Btn_AddCategory.Margin = new Padding(4);
            Btn_AddCategory.Name = "Btn_AddCategory";
            Btn_AddCategory.Size = new Size(131, 95);
            Btn_AddCategory.TabIndex = 8;
            Btn_AddCategory.Text = "Add Category";
            Btn_AddCategory.UseVisualStyleBackColor = false;
            // 
            // buttonremovecategory
            // 
            buttonremovecategory.BackColor = Color.Red;
            buttonremovecategory.Location = new Point(1097, 388);
            buttonremovecategory.Margin = new Padding(4);
            buttonremovecategory.Name = "buttonremovecategory";
            buttonremovecategory.Size = new Size(131, 95);
            buttonremovecategory.TabIndex = 9;
            buttonremovecategory.Text = "Remove Category";
            buttonremovecategory.UseVisualStyleBackColor = false;
            // 
            // Lbl_CategoryName
            // 
            Lbl_CategoryName.AutoSize = true;
            Lbl_CategoryName.Location = new Point(818, 339);
            Lbl_CategoryName.Margin = new Padding(4, 0, 4, 0);
            Lbl_CategoryName.Name = "Lbl_CategoryName";
            Lbl_CategoryName.Size = new Size(83, 32);
            Lbl_CategoryName.TabIndex = 10;
            Lbl_CategoryName.Text = "Name:";
            // 
            // Lbl_ProductName
            // 
            Lbl_ProductName.AutoSize = true;
            Lbl_ProductName.Location = new Point(44, 447);
            Lbl_ProductName.Margin = new Padding(4, 0, 4, 0);
            Lbl_ProductName.Name = "Lbl_ProductName";
            Lbl_ProductName.Size = new Size(83, 32);
            Lbl_ProductName.TabIndex = 11;
            Lbl_ProductName.Text = "Name:";
            // 
            // Tb_ProductName
            // 
            Tb_ProductName.Location = new Point(140, 443);
            Tb_ProductName.Margin = new Padding(4);
            Tb_ProductName.Name = "Tb_ProductName";
            Tb_ProductName.Size = new Size(580, 39);
            Tb_ProductName.TabIndex = 12;
            // 
            // Tb_CategoryName
            // 
            Tb_CategoryName.Location = new Point(914, 339);
            Tb_CategoryName.Margin = new Padding(4);
            Tb_CategoryName.Name = "Tb_CategoryName";
            Tb_CategoryName.Size = new Size(371, 39);
            Tb_CategoryName.TabIndex = 13;
            // 
            // Lbl_ProductCategory
            // 
            Lbl_ProductCategory.AutoSize = true;
            Lbl_ProductCategory.Location = new Point(12, 516);
            Lbl_ProductCategory.Margin = new Padding(4, 0, 4, 0);
            Lbl_ProductCategory.Name = "Lbl_ProductCategory";
            Lbl_ProductCategory.Size = new Size(115, 32);
            Lbl_ProductCategory.TabIndex = 14;
            Lbl_ProductCategory.Text = "Category:";
            // 
            // Lbl_ProductPrice
            // 
            Lbl_ProductPrice.AutoSize = true;
            Lbl_ProductPrice.Location = new Point(50, 581);
            Lbl_ProductPrice.Margin = new Padding(4, 0, 4, 0);
            Lbl_ProductPrice.Name = "Lbl_ProductPrice";
            Lbl_ProductPrice.Size = new Size(70, 32);
            Lbl_ProductPrice.TabIndex = 15;
            Lbl_ProductPrice.Text = "Price:";
            // 
            // Lbl_ProductStock
            // 
            Lbl_ProductStock.AutoSize = true;
            Lbl_ProductStock.Location = new Point(44, 654);
            Lbl_ProductStock.Margin = new Padding(4, 0, 4, 0);
            Lbl_ProductStock.Name = "Lbl_ProductStock";
            Lbl_ProductStock.Size = new Size(76, 32);
            Lbl_ProductStock.TabIndex = 16;
            Lbl_ProductStock.Text = "Stock:";
            // 
            // Tb_ProductPrice
            // 
            Tb_ProductPrice.Location = new Point(140, 581);
            Tb_ProductPrice.Margin = new Padding(4);
            Tb_ProductPrice.Name = "Tb_ProductPrice";
            Tb_ProductPrice.Size = new Size(194, 39);
            Tb_ProductPrice.TabIndex = 17;
            // 
            // Tb_ProductStock
            // 
            Tb_ProductStock.Location = new Point(140, 654);
            Tb_ProductStock.Margin = new Padding(4);
            Tb_ProductStock.Name = "Tb_ProductStock";
            Tb_ProductStock.Size = new Size(194, 39);
            Tb_ProductStock.TabIndex = 18;
            // 
            // Cbox_ProductCategory
            // 
            Cbox_ProductCategory.FormattingEnabled = true;
            Cbox_ProductCategory.Location = new Point(140, 512);
            Cbox_ProductCategory.Margin = new Padding(4);
            Cbox_ProductCategory.Name = "Cbox_ProductCategory";
            Cbox_ProductCategory.Size = new Size(242, 40);
            Cbox_ProductCategory.TabIndex = 19;
            // 
            // Btn_AddProduct
            // 
            Btn_AddProduct.BackColor = Color.Lime;
            Btn_AddProduct.Location = new Point(363, 588);
            Btn_AddProduct.Margin = new Padding(4);
            Btn_AddProduct.Name = "Btn_AddProduct";
            Btn_AddProduct.Size = new Size(121, 95);
            Btn_AddProduct.TabIndex = 20;
            Btn_AddProduct.Text = "Add Product";
            Btn_AddProduct.UseVisualStyleBackColor = false;
            // 
            // Btn_RemoveProduct
            // 
            Btn_RemoveProduct.BackColor = Color.Red;
            Btn_RemoveProduct.Location = new Point(620, 588);
            Btn_RemoveProduct.Margin = new Padding(4);
            Btn_RemoveProduct.Name = "Btn_RemoveProduct";
            Btn_RemoveProduct.Size = new Size(123, 95);
            Btn_RemoveProduct.TabIndex = 21;
            Btn_RemoveProduct.Text = "Remove Product";
            Btn_RemoveProduct.UseVisualStyleBackColor = false;
            // 
            // Btn_EditProduct
            // 
            Btn_EditProduct.BackColor = Color.Yellow;
            Btn_EditProduct.Location = new Point(491, 588);
            Btn_EditProduct.Margin = new Padding(4);
            Btn_EditProduct.Name = "Btn_EditProduct";
            Btn_EditProduct.Size = new Size(121, 95);
            Btn_EditProduct.TabIndex = 22;
            Btn_EditProduct.Text = "Edit Product";
            Btn_EditProduct.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkTurquoise;
            ClientSize = new Size(1301, 698);
            Controls.Add(Btn_EditProduct);
            Controls.Add(Btn_RemoveProduct);
            Controls.Add(Btn_AddProduct);
            Controls.Add(Cbox_ProductCategory);
            Controls.Add(Tb_ProductStock);
            Controls.Add(Tb_ProductPrice);
            Controls.Add(Lbl_ProductStock);
            Controls.Add(Lbl_ProductPrice);
            Controls.Add(Lbl_ProductCategory);
            Controls.Add(Tb_CategoryName);
            Controls.Add(Tb_ProductName);
            Controls.Add(Lbl_ProductName);
            Controls.Add(Lbl_CategoryName);
            Controls.Add(buttonremovecategory);
            Controls.Add(Btn_AddCategory);
            Controls.Add(Lbl_ProductDetails);
            Controls.Add(Cbox_Filter);
            Controls.Add(Btn_All);
            Controls.Add(Btn_Filter);
            Controls.Add(Lbl_Category);
            Controls.Add(Lbl_Product);
            Controls.Add(Dgv_Category);
            Controls.Add(Dgv_Product);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)Dgv_Product).EndInit();
            ((System.ComponentModel.ISupportInitialize)Dgv_Category).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView Dgv_Product;
        private DataGridView Dgv_Category;
        private Label Lbl_Product;
        private Label Lbl_Category;
        private Button Btn_Filter;
        private Button Btn_All;
        private ComboBox Cbox_Filter;
        private Label Lbl_ProductDetails;
        private Button Btn_AddCategory;
        private Button buttonremovecategory;
        private Label Lbl_CategoryName;
        private Label Lbl_ProductName;
        private TextBox Tb_ProductName;
        private TextBox Tb_CategoryName;
        private Label Lbl_ProductCategory;
        private Label Lbl_ProductPrice;
        private Label Lbl_ProductStock;
        private TextBox Tb_ProductPrice;
        private TextBox Tb_ProductStock;
        private ComboBox Cbox_ProductCategory;
        private Button Btn_AddProduct;
        private Button Btn_RemoveProduct;
        private Button Btn_EditProduct;
    }
}