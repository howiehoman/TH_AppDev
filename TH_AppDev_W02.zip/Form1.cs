﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace Game
{
    public partial class Form1 : Form
    {
        private List<string> letters = new List<string>() { "", "", "", "", "" };
        private int winCount = 0;
        private string selectedLetter = "";
        private Random random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            int length1 = tbWord1.Text.Length;
            int length2 = tbWord2.Text.Length;
            int length3 = tbWord3.Text.Length;
            int length4 = tbWord4.Text.Length;
            int length5 = tbWord5.Text.Length;

            if (length1 == 5 && length2 == 5 && length3 == 5 && length4 == 5 && length5 == 5 &&
                tbWord1.Text != tbWord2.Text && tbWord1.Text != tbWord3.Text && tbWord1.Text != tbWord4.Text && tbWord1.Text != tbWord5.Text &&
                tbWord2.Text != tbWord3.Text && tbWord2.Text != tbWord4.Text && tbWord2.Text != tbWord5.Text && tbWord3.Text != tbWord4.Text &&
                tbWord3.Text != tbWord5.Text && tbWord4.Text != tbWord5.Text)
            {
                panelPlayGame.Visible = true;
                panelUtama.Visible = false;
                Random random = new Random();
                int randomNumber = random.Next(1, 6);
                string randomWord = "";
                if (randomNumber == 1)
                {
                    randomWord = tbWord1.Text;
                }
                else if (randomNumber == 2)
                {
                    randomWord = tbWord2.Text;
                }
                else if (randomNumber == 3)
                {
                    randomWord = tbWord3.Text;
                }
                else if (randomNumber == 4)
                {
                    randomWord = tbWord4.Text;
                }
                else if (randomNumber == 5)
                {
                    randomWord = tbWord5.Text;
                }
                int i = 0;
                foreach (char letter in randomWord)
                {
                    string letterAsString = letter.ToString();
                    letters[i] = letterAsString;
                    i++;
                }
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void UpdateLabelsWithLetters()
        {
            if (selectedLetter == letters[0])
            {
                lblKataPertama.Text = selectedLetter;
                winCount++;
            }
            if (selectedLetter == letters[1])
            {
                lblKataKedua.Text = selectedLetter;
                winCount++;
            }
            if (selectedLetter == letters[2])
            {
                lblKataKetiga.Text = selectedLetter;
                winCount++;
            }
            if (selectedLetter == letters[3])
            {
                lblKataKeempat.Text = selectedLetter;
                winCount++;
            }
            if (selectedLetter == letters[4])
            {
                lblKataKelima.Text = selectedLetter;
                winCount++;
            }
            if (winCount == 5)
            {
                MessageBox.Show("You Win!");
                panelWin.Visible = true;
            }
        }

        private void btnQ_Click(object sender, EventArgs e)
        {
            selectedLetter = "q";
            UpdateLabelsWithLetters();
            btnQ.Enabled = false;
        }

        private void btnT_Click(object sender, EventArgs e)
        {
            selectedLetter = "t";
            UpdateLabelsWithLetters();
            btnT.Enabled = false;
        }

        private void btnY_Click(object sender, EventArgs e)
        {
            selectedLetter = "y";
            UpdateLabelsWithLetters();
            btnY.Enabled = false;
        }

        private void btnU_Click(object sender, EventArgs e)
        {
            selectedLetter = "u";
            UpdateLabelsWithLetters();
            btnU.Enabled = false;
        }

        private void btnI_Click(object sender, EventArgs e)
        {
            selectedLetter = "i";
            UpdateLabelsWithLetters();
            btnI.Enabled = false;
        }

        private void btnO_Click(object sender, EventArgs e)
        {
            selectedLetter = "o";
            UpdateLabelsWithLetters();
            btnO.Enabled = false;
        }

        private void btnP_Click(object sender, EventArgs e)
        {
            selectedLetter = "p";
            UpdateLabelsWithLetters();
            btnP.Enabled = false;
        }

        private void btnA_Click(object sender, EventArgs e)
        {
            selectedLetter = "a";
            UpdateLabelsWithLetters();
            btnA.Enabled = false;
        }

        private void btnS_Click(object sender, EventArgs e)
        {
            selectedLetter = "s";
            UpdateLabelsWithLetters();
            btnS.Enabled = false;
        }

        private void btnD_Click(object sender, EventArgs e)
        {
            selectedLetter = "d";
            UpdateLabelsWithLetters();
            btnD.Enabled = false;
        }

        private void btnF_Click(object sender, EventArgs e)
        {
            selectedLetter = "f";
            UpdateLabelsWithLetters();
            btnF.Enabled = false;
        }

        private void btnG_Click(object sender, EventArgs e)
        {
            selectedLetter = "g";
            UpdateLabelsWithLetters();
            btnG.Enabled = false;
        }

        private void btnJ_Click(object sender, EventArgs e)
        {
            selectedLetter = "j";
            UpdateLabelsWithLetters();
            btnJ.Enabled = false;
        }

        private void btnK_Click(object sender, EventArgs e)
        {
            selectedLetter = "k";
            UpdateLabelsWithLetters();
            btnK.Enabled = false;
        }

        private void btnL_Click(object sender, EventArgs e)
        {
            selectedLetter = "l";
            UpdateLabelsWithLetters();
            btnL.Enabled = false;
        }

        private void btnZ_Click(object sender, EventArgs e)
        {
            selectedLetter = "z";
            UpdateLabelsWithLetters();
            btnZ.Enabled = false;
        }

        private void btnX_Click(object sender, EventArgs e)
        {
            selectedLetter = "x";
            UpdateLabelsWithLetters();
            btnX.Enabled = false;
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            selectedLetter = "c";
            UpdateLabelsWithLetters();
            btnC.Enabled = false;
        }

        private void btnV_Click(object sender, EventArgs e)
        {
            selectedLetter = "v";
            UpdateLabelsWithLetters();
            btnV.Enabled = false;
        }

        private void btnB_Click(object sender, EventArgs e)
        {
            selectedLetter = "b";
            UpdateLabelsWithLetters();
            btnB.Enabled = false;
        }

        private void btnN_Click(object sender, EventArgs e)
        {
            selectedLetter = "n";
            UpdateLabelsWithLetters();
            btnN.Enabled = false;
        }

        private void btnM_Click(object sender, EventArgs e)
        {
            selectedLetter = "m";
            UpdateLabelsWithLetters();
            btnM.Enabled = false;
        }

        private void btnE_Click(object sender, EventArgs e)
        {
            selectedLetter = "e";
            UpdateLabelsWithLetters();
            btnE.Enabled = false;
        }

        private void btnW_Click(object sender, EventArgs e)
        {
            selectedLetter = "w";
            UpdateLabelsWithLetters();
            btnW.Enabled = false;
        }

        private void btnH_Click(object sender, EventArgs e)
        {
            selectedLetter = "h";
            UpdateLabelsWithLetters();
            btnH.Enabled = false;
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            selectedLetter = "r";
            UpdateLabelsWithLetters();
            btnR.Enabled = false;
        }

        
    }
}