﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection SqlConnect;
        MySqlCommand SqlCommand;
        MySqlDataAdapter SqlDataAdapter;
        string SqlQuery;
        DataTable dtTeam;
        DataTable dtTeam1;
        DataTable dtPlayer;
        DataTable dtDate;
        DataTable dtDgv;
        DataTable dtTempo;
        string date;
        string tempo;

        private void Form1_Load(object sender, EventArgs e)
        {
            dtTeam = new DataTable();
            dtTeam1 = new DataTable();
            SqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
            SqlConnect.Open();
            SqlQuery = "SELECT team_name, team_id FROM team;";
            SqlCommand = new MySqlCommand(SqlQuery, SqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            SqlDataAdapter.Fill(dtTeam);
            SqlDataAdapter.Fill(dtTeam1);

            Cbox_TeamHome.DataSource = dtTeam;
            Cbox_TeamHome.DisplayMember = "team_name";
            Cbox_TeamHome.ValueMember = "team_id";
            Cbox_TeamAway.DataSource = dtTeam1;
            Cbox_TeamAway.DisplayMember = "team_name";
            Cbox_TeamAway.ValueMember = "team_id";

            Cbox_TeamHome.SelectedIndex = -1;
            Cbox_TeamAway.SelectedIndex = -1;

            Cbox_Type.Items.Add("GO");
            Cbox_Type.Items.Add("GP");
            Cbox_Type.Items.Add("GW");
            Cbox_Type.Items.Add("CR");
            Cbox_Type.Items.Add("CY");
            Cbox_Type.Items.Add("PM");

            dtDgv = new DataTable();

            dtDgv.Columns.Add("Minute");
            dtDgv.Columns.Add("Team");
            dtDgv.Columns.Add("Player");
            dtDgv.Columns.Add("Type");

        }

        private void Dtp_MatchDate_ValueChanged(object sender, EventArgs e)
        {
            dtDate = new DataTable();
            date = Dtp_MatchDate.Value.ToString("yyyy-MM-dd");
            try
            {
                string QueryID = $"SELECT COUNT(match_id) FROM `match` WHERE match_id LIKE '{Dtp_MatchDate.Value.Year}%'";
                SqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                SqlConnect.Open();
                SqlCommand = new MySqlCommand(QueryID, SqlConnect);
                SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
                SqlDataAdapter.Fill(dtDate);
                int Amount = Convert.ToInt32(dtDate.Rows[0][0]) + 1;
                if (Amount < 10)
                {
                    tempo = $"{Dtp_MatchDate.Value.Year}00{Amount}";
                }
                else if (Amount < 100)
                {
                    tempo = $"{Dtp_MatchDate.Value.Year}0{Amount}";
                }
                else
                {
                    tempo = $"{Dtp_MatchDate.Value.Year}{Amount}";
                }
                Tb_MatchID.Text = tempo;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Cbox_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            Cbox_Team.Items.Clear();
            if (Cbox_TeamHome.SelectedIndex == Cbox_TeamAway.SelectedIndex)
            {
                MessageBox.Show("Pilih Home Team Lain");
            }
            else
            {
                Cbox_Team.Items.Add(Cbox_TeamHome.Text);
                Cbox_Team.Items.Add(Cbox_TeamAway.Text);
            }
        }

        private void Cbox_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            Cbox_Team.Items.Clear();
            if (Cbox_TeamAway.SelectedIndex == Cbox_TeamHome.SelectedIndex)
            {
                MessageBox.Show("Pilih Away Team Lain");
            }
            else
            {
                Cbox_Team.Items.Add(Cbox_TeamHome.Text);
                Cbox_Team.Items.Add(Cbox_TeamAway.Text);
            }
        }

        private void Cbox_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtPlayer = new DataTable();
            try
            {
                string QueryPlayer = $"SELECT p.player_name FROM player p, team t WHERE p.team_id = t.team_id AND (t.team_name = '{Cbox_Team.Text}') ;";
                SqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                SqlConnect.Open();
                SqlCommand = new MySqlCommand(QueryPlayer, SqlConnect);
                SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
                SqlDataAdapter.Fill(dtPlayer);
                SqlConnect.Close();
                Cbox_Player.DataSource = dtPlayer;
                Cbox_Player.DisplayMember = "player_name";
                Cbox_Player.ValueMember = "player_id";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            dtDgv.Rows.Add(Tb_Minute.Text,Cbox_Team.Text,Cbox_Player.Text,Cbox_Type.Text);
            Dgv_Team.DataSource = dtDgv;
        }

        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            dtDgv.Rows.RemoveAt(Dgv_Team.CurrentCell.RowIndex);
            Dgv_Team.DataSource= dtDgv;
        }

        private void Btn_Insert_Click(object sender, EventArgs e)
        {
            dtTempo = new DataTable();
            foreach (DataRow data in dtDgv.Rows)
            {
                try
                {
                    string QueryTempo = $"SELECT player_id FROM player WHERE player.player_name = '{data[2]}';";
                    string QueryInsert = $"INSERT INTO dmatch ('match_id','minute','team_id','player_id','type','delete') VALUES ('{Tb_MatchID.Text}','{data[0]}','{data[1]}','{data[2]}','{data[3]}','0',";
                    SqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                    SqlConnect.Open();
                    SqlCommand = new MySqlCommand(QueryTempo, SqlConnect);
                    SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
                    SqlDataAdapter.Fill(dtTempo);
                    SqlConnect.Close();
                    Dgv_Team.DataSource = dtTempo;
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
