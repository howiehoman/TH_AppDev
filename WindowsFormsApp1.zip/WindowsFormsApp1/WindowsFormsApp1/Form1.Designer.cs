﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbl_MatchID = new System.Windows.Forms.Label();
            this.Lbl_TeamHome = new System.Windows.Forms.Label();
            this.Lbl_MatchDate = new System.Windows.Forms.Label();
            this.Lbl_TeamAway = new System.Windows.Forms.Label();
            this.Lbl_Type = new System.Windows.Forms.Label();
            this.Lbl_Minute = new System.Windows.Forms.Label();
            this.Lbl_Team = new System.Windows.Forms.Label();
            this.Lbl_Player = new System.Windows.Forms.Label();
            this.Tb_MatchID = new System.Windows.Forms.TextBox();
            this.Tb_Minute = new System.Windows.Forms.TextBox();
            this.Cbox_TeamHome = new System.Windows.Forms.ComboBox();
            this.Cbox_TeamAway = new System.Windows.Forms.ComboBox();
            this.Cbox_Team = new System.Windows.Forms.ComboBox();
            this.Cbox_Player = new System.Windows.Forms.ComboBox();
            this.Cbox_Type = new System.Windows.Forms.ComboBox();
            this.Dtp_MatchDate = new System.Windows.Forms.DateTimePicker();
            this.Dgv_Team = new System.Windows.Forms.DataGridView();
            this.Btn_Add = new System.Windows.Forms.Button();
            this.Btn_Delete = new System.Windows.Forms.Button();
            this.Btn_Insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Team)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl_MatchID
            // 
            this.Lbl_MatchID.AutoSize = true;
            this.Lbl_MatchID.Location = new System.Drawing.Point(47, 46);
            this.Lbl_MatchID.Name = "Lbl_MatchID";
            this.Lbl_MatchID.Size = new System.Drawing.Size(97, 25);
            this.Lbl_MatchID.TabIndex = 0;
            this.Lbl_MatchID.Text = "Match ID";
            // 
            // Lbl_TeamHome
            // 
            this.Lbl_TeamHome.AutoSize = true;
            this.Lbl_TeamHome.Location = new System.Drawing.Point(47, 112);
            this.Lbl_TeamHome.Name = "Lbl_TeamHome";
            this.Lbl_TeamHome.Size = new System.Drawing.Size(128, 25);
            this.Lbl_TeamHome.TabIndex = 1;
            this.Lbl_TeamHome.Text = "Team Home";
            // 
            // Lbl_MatchDate
            // 
            this.Lbl_MatchDate.AutoSize = true;
            this.Lbl_MatchDate.Location = new System.Drawing.Point(690, 46);
            this.Lbl_MatchDate.Name = "Lbl_MatchDate";
            this.Lbl_MatchDate.Size = new System.Drawing.Size(122, 25);
            this.Lbl_MatchDate.TabIndex = 2;
            this.Lbl_MatchDate.Text = "Match Date";
            // 
            // Lbl_TeamAway
            // 
            this.Lbl_TeamAway.AutoSize = true;
            this.Lbl_TeamAway.Location = new System.Drawing.Point(690, 112);
            this.Lbl_TeamAway.Name = "Lbl_TeamAway";
            this.Lbl_TeamAway.Size = new System.Drawing.Size(124, 25);
            this.Lbl_TeamAway.TabIndex = 3;
            this.Lbl_TeamAway.Text = "Team Away";
            // 
            // Lbl_Type
            // 
            this.Lbl_Type.AutoSize = true;
            this.Lbl_Type.Location = new System.Drawing.Point(871, 502);
            this.Lbl_Type.Name = "Lbl_Type";
            this.Lbl_Type.Size = new System.Drawing.Size(60, 25);
            this.Lbl_Type.TabIndex = 4;
            this.Lbl_Type.Text = "Type";
            // 
            // Lbl_Minute
            // 
            this.Lbl_Minute.AutoSize = true;
            this.Lbl_Minute.Location = new System.Drawing.Point(871, 329);
            this.Lbl_Minute.Name = "Lbl_Minute";
            this.Lbl_Minute.Size = new System.Drawing.Size(77, 25);
            this.Lbl_Minute.TabIndex = 5;
            this.Lbl_Minute.Text = "Minute";
            // 
            // Lbl_Team
            // 
            this.Lbl_Team.AutoSize = true;
            this.Lbl_Team.Location = new System.Drawing.Point(871, 386);
            this.Lbl_Team.Name = "Lbl_Team";
            this.Lbl_Team.Size = new System.Drawing.Size(66, 25);
            this.Lbl_Team.TabIndex = 6;
            this.Lbl_Team.Text = "Team";
            // 
            // Lbl_Player
            // 
            this.Lbl_Player.AutoSize = true;
            this.Lbl_Player.Location = new System.Drawing.Point(871, 442);
            this.Lbl_Player.Name = "Lbl_Player";
            this.Lbl_Player.Size = new System.Drawing.Size(73, 25);
            this.Lbl_Player.TabIndex = 7;
            this.Lbl_Player.Text = "Player";
            // 
            // Tb_MatchID
            // 
            this.Tb_MatchID.Enabled = false;
            this.Tb_MatchID.Location = new System.Drawing.Point(199, 40);
            this.Tb_MatchID.Name = "Tb_MatchID";
            this.Tb_MatchID.Size = new System.Drawing.Size(294, 31);
            this.Tb_MatchID.TabIndex = 8;
            // 
            // Tb_Minute
            // 
            this.Tb_Minute.Location = new System.Drawing.Point(970, 323);
            this.Tb_Minute.Name = "Tb_Minute";
            this.Tb_Minute.Size = new System.Drawing.Size(294, 31);
            this.Tb_Minute.TabIndex = 9;
            // 
            // Cbox_TeamHome
            // 
            this.Cbox_TeamHome.FormattingEnabled = true;
            this.Cbox_TeamHome.Location = new System.Drawing.Point(199, 112);
            this.Cbox_TeamHome.Name = "Cbox_TeamHome";
            this.Cbox_TeamHome.Size = new System.Drawing.Size(294, 33);
            this.Cbox_TeamHome.TabIndex = 10;
            this.Cbox_TeamHome.SelectedIndexChanged += new System.EventHandler(this.Cbox_TeamHome_SelectedIndexChanged);
            // 
            // Cbox_TeamAway
            // 
            this.Cbox_TeamAway.FormattingEnabled = true;
            this.Cbox_TeamAway.Location = new System.Drawing.Point(834, 109);
            this.Cbox_TeamAway.Name = "Cbox_TeamAway";
            this.Cbox_TeamAway.Size = new System.Drawing.Size(294, 33);
            this.Cbox_TeamAway.TabIndex = 11;
            this.Cbox_TeamAway.SelectedIndexChanged += new System.EventHandler(this.Cbox_TeamAway_SelectedIndexChanged);
            // 
            // Cbox_Team
            // 
            this.Cbox_Team.FormattingEnabled = true;
            this.Cbox_Team.Location = new System.Drawing.Point(970, 383);
            this.Cbox_Team.Name = "Cbox_Team";
            this.Cbox_Team.Size = new System.Drawing.Size(294, 33);
            this.Cbox_Team.TabIndex = 12;
            this.Cbox_Team.SelectedIndexChanged += new System.EventHandler(this.Cbox_Team_SelectedIndexChanged);
            // 
            // Cbox_Player
            // 
            this.Cbox_Player.FormattingEnabled = true;
            this.Cbox_Player.Location = new System.Drawing.Point(970, 439);
            this.Cbox_Player.Name = "Cbox_Player";
            this.Cbox_Player.Size = new System.Drawing.Size(294, 33);
            this.Cbox_Player.TabIndex = 13;
            // 
            // Cbox_Type
            // 
            this.Cbox_Type.FormattingEnabled = true;
            this.Cbox_Type.Location = new System.Drawing.Point(970, 499);
            this.Cbox_Type.Name = "Cbox_Type";
            this.Cbox_Type.Size = new System.Drawing.Size(294, 33);
            this.Cbox_Type.TabIndex = 14;
            // 
            // Dtp_MatchDate
            // 
            this.Dtp_MatchDate.Location = new System.Drawing.Point(834, 41);
            this.Dtp_MatchDate.Name = "Dtp_MatchDate";
            this.Dtp_MatchDate.Size = new System.Drawing.Size(400, 31);
            this.Dtp_MatchDate.TabIndex = 15;
            this.Dtp_MatchDate.ValueChanged += new System.EventHandler(this.Dtp_MatchDate_ValueChanged);
            // 
            // Dgv_Team
            // 
            this.Dgv_Team.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Team.Location = new System.Drawing.Point(29, 257);
            this.Dgv_Team.Name = "Dgv_Team";
            this.Dgv_Team.RowHeadersWidth = 82;
            this.Dgv_Team.RowTemplate.Height = 33;
            this.Dgv_Team.Size = new System.Drawing.Size(771, 428);
            this.Dgv_Team.TabIndex = 16;
            // 
            // Btn_Add
            // 
            this.Btn_Add.Location = new System.Drawing.Point(908, 565);
            this.Btn_Add.Name = "Btn_Add";
            this.Btn_Add.Size = new System.Drawing.Size(158, 55);
            this.Btn_Add.TabIndex = 17;
            this.Btn_Add.Text = "Add";
            this.Btn_Add.UseVisualStyleBackColor = true;
            this.Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // Btn_Delete
            // 
            this.Btn_Delete.Location = new System.Drawing.Point(1106, 565);
            this.Btn_Delete.Name = "Btn_Delete";
            this.Btn_Delete.Size = new System.Drawing.Size(158, 55);
            this.Btn_Delete.TabIndex = 18;
            this.Btn_Delete.Text = "Delete";
            this.Btn_Delete.UseVisualStyleBackColor = true;
            this.Btn_Delete.Click += new System.EventHandler(this.Btn_Delete_Click);
            // 
            // Btn_Insert
            // 
            this.Btn_Insert.Location = new System.Drawing.Point(466, 746);
            this.Btn_Insert.Name = "Btn_Insert";
            this.Btn_Insert.Size = new System.Drawing.Size(465, 55);
            this.Btn_Insert.TabIndex = 19;
            this.Btn_Insert.Text = "Insert";
            this.Btn_Insert.UseVisualStyleBackColor = true;
            this.Btn_Insert.Click += new System.EventHandler(this.Btn_Insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1339, 829);
            this.Controls.Add(this.Btn_Insert);
            this.Controls.Add(this.Btn_Delete);
            this.Controls.Add(this.Btn_Add);
            this.Controls.Add(this.Dgv_Team);
            this.Controls.Add(this.Dtp_MatchDate);
            this.Controls.Add(this.Cbox_Type);
            this.Controls.Add(this.Cbox_Player);
            this.Controls.Add(this.Cbox_Team);
            this.Controls.Add(this.Cbox_TeamAway);
            this.Controls.Add(this.Cbox_TeamHome);
            this.Controls.Add(this.Tb_Minute);
            this.Controls.Add(this.Tb_MatchID);
            this.Controls.Add(this.Lbl_Player);
            this.Controls.Add(this.Lbl_Team);
            this.Controls.Add(this.Lbl_Minute);
            this.Controls.Add(this.Lbl_Type);
            this.Controls.Add(this.Lbl_TeamAway);
            this.Controls.Add(this.Lbl_MatchDate);
            this.Controls.Add(this.Lbl_TeamHome);
            this.Controls.Add(this.Lbl_MatchID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Team)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_MatchID;
        private System.Windows.Forms.Label Lbl_TeamHome;
        private System.Windows.Forms.Label Lbl_MatchDate;
        private System.Windows.Forms.Label Lbl_TeamAway;
        private System.Windows.Forms.Label Lbl_Type;
        private System.Windows.Forms.Label Lbl_Minute;
        private System.Windows.Forms.Label Lbl_Team;
        private System.Windows.Forms.Label Lbl_Player;
        private System.Windows.Forms.TextBox Tb_MatchID;
        private System.Windows.Forms.TextBox Tb_Minute;
        private System.Windows.Forms.ComboBox Cbox_TeamHome;
        private System.Windows.Forms.ComboBox Cbox_TeamAway;
        private System.Windows.Forms.ComboBox Cbox_Team;
        private System.Windows.Forms.ComboBox Cbox_Player;
        private System.Windows.Forms.ComboBox Cbox_Type;
        private System.Windows.Forms.DateTimePicker Dtp_MatchDate;
        private System.Windows.Forms.DataGridView Dgv_Team;
        private System.Windows.Forms.Button Btn_Add;
        private System.Windows.Forms.Button Btn_Delete;
        private System.Windows.Forms.Button Btn_Insert;
    }
}

