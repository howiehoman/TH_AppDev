namespace AppDev_Takehome_W04
{
    public partial class Form1 : Form
    {
        List<Team> teams;
        List<string> country;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Player> PlayerTeam1 = new List<Player>
            {
                new Player("1", "Ter Stegen", "GK"),
                new Player("4", "Ronald Araujo", "DF"),
                new Player("3", "Alejandro Balde", "DF"),
                new Player("17", "Marcos Alonso", "DF"),
                new Player("23", "Jules Kounde", "DF"),
                new Player("6", "Pablo Gavi", "MF"),
                new Player("8", "Pedri", "MF"),
                new Player("21", "Frenkie de Jong", "MF"),
                new Player("14", "Joao Felix", "FW"),
                new Player("9", "Robert Lewandowski", "FW"),
                new Player("27", "Lamine Yamal", "FW")
            };

            List<Player> PlayerTeam2 = new List<Player>
            {
                new Player("31", "Ederson", "GK"),
                new Player("2", "Kyle Walker", "DF"),
                new Player("5", "John Stones", "DF"),
                new Player("27", "Joao Cancelo", "DF"),
                new Player("3", "Ruben Dias", "DF"),
                new Player("25", "Fernandinho", "MF"),
                new Player("17", "Kevin De Bruyne", "MF"),
                new Player("47", "Phil Foden", "MF"),
                new Player("26", "Riyad Mahrez", "FW"),
                new Player("9", "Erling Haaland", "FW"),
                new Player("19", "Julian Alvarez", "FW")
            };
            List<Player> PlayerTeam3 = new List<Player>
            {
                new Player("99", "Gianluigi Donnarumma", "GK"),
                new Player("2", "Achraf Hakimi", "DF"),
                new Player("3", "Presnel Kimpembe", "DF"),
                new Player("5", "Marquinhos", "DF"),
                new Player("20", "Layvin Kurzawa", "DF"),
                new Player("8", "Fabian Ruiz", "MF"),
                new Player("17", "Vitinha", "MF"),
                new Player("33", "Warren Zaire-Emery", "MF"),
                new Player("10", "Ousmane Dembele", "MF"),
                new Player("11", "Marco Asensio", "FW"),
                new Player("7", "Kylian Mbappe", "FW")
            };
            Team Team1 = new Team("FC Barcelona", "Spain", "Barcelona", PlayerTeam1);
            Team Team2 = new Team("Manchester City", "England", "Manchester", PlayerTeam2);
            Team Team3 = new Team("Paris Saint Germain", "France", "Paris", PlayerTeam3);
            teams = new List<Team> { Team1, Team2, Team3 };
            country = new List<string> { "Spain", "England", "France" };
            Cobx_ChooseCountry.DataSource = country;
            Cobx_ChooseCountry.SelectedIndex = -1;
            Cobx_ChooseTeam.SelectedIndex = -1;
            Lbx_Player.Items.Clear();
        }

        private void Cobx_ChooseCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ChooseCountry = (string)Cobx_ChooseCountry.SelectedItem;
            List<Team> TeamMembers = new List<Team>();
            foreach (Team a in teams)
            {
                if (a.teamcountry == ChooseCountry)
                {
                    TeamMembers.Add(a);
                }
            }
            Cobx_ChooseTeam.DataSource = TeamMembers;
            Cobx_ChooseTeam.DisplayMember = "Team Name";
        }

        private void Cobx_ChooseTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            Lbx_Player.Items.Clear();
            Team ChooseTeam = (Team)Cobx_ChooseTeam.SelectedItem;
            if (ChooseTeam.players != null)
            {
                foreach (Player a in ChooseTeam.players)
                {
                    Lbx_Player.Items.Add("[" + a.playernumber + "] " + a.playername + ", " + a.playerposition);
                }
            }
        }

        private void Btn_AddTeam_Click(object sender, EventArgs e)
        {
            if (Tbx_TeamName.Text == "" || Tbx_TeamCountry.Text == "" || Tbx_TeamCity.Text == "")
            {
                MessageBox.Show("All textboxes must be filled!", "!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                bool YesOrNo = true;
                foreach (Team a in teams)
                {
                    YesOrNo = false;
                    break;
                }
                if (YesOrNo = false)
                {
                    MessageBox.Show("Team Name has already been used!");
                }
                else
                {
                    Team NewTeam = new Team(Tbx_TeamName.Text, Tbx_TeamCountry.Text, Tbx_TeamCity.Text, new List<Player>());
                    teams.Add(NewTeam);
                    Cobx_ChooseCountry.SelectedIndex = -1;
                    if (!country.Contains(Tbx_TeamCountry.Text))
                    {
                        country.Add(Tbx_TeamCountry.Text);
                        Cobx_ChooseCountry.DataSource = null;
                        Cobx_ChooseCountry.DataSource = country;
                    }
                    Tbx_TeamName.Text = "";
                    Tbx_TeamCountry.Text = "";
                    Tbx_TeamCity.Text = "";
                }


            }
        }

        private void Btn_AddPlayer_Click(object sender, EventArgs e)
        {
            if (Tbx_PlayerName.Text == "" || Tbx_PlayerNumber.Text == "" || (string)Cobx_PlayerPosition.SelectedItem == "")
            {
                MessageBox.Show("All textboxes must be filled!", "!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                bool YesOrNo = true;
                Team ChooseTeam = (Team)Cobx_ChooseTeam.SelectedItem;
                string Position = (string)Cobx_PlayerPosition.SelectedItem;
                Player NewPlayer = new Player(Tbx_PlayerNumber.Text, Tbx_PlayerName.Text, Position);
                foreach (Player a in ChooseTeam.players)
                {
                    if (a.playername == Tbx_PlayerName.Text || a.playernumber == Tbx_PlayerNumber.Text)
                    {
                        YesOrNo = false;
                        break;
                    }
                }
                if (YesOrNo == false)
                {
                    MessageBox.Show("Player Name/Number has already been used!");
                }
                else
                {
                    ChooseTeam.players.Add(NewPlayer);
                    Lbx_Player.Items.Clear();
                    foreach (Player b in ChooseTeam.players)
                    {
                        Lbx_Player.Items.Add("[" + b.playernumber + "] " + b.playername + ", " + b.playerposition);
                    }
                    Tbx_PlayerName.Text = "";
                    Tbx_PlayerNumber.Text = "";
                    Cobx_PlayerPosition.SelectedIndex = -1;
                }
            }
        }

        private void Btn_Remove_Click(object sender, EventArgs e)
        {
            int Remove = Lbx_Player.SelectedIndex;
            Team ChooseTeam = (Team)Cobx_ChooseTeam.SelectedItem;
            if (ChooseTeam.players.Count > 11)
            {
                ChooseTeam.players.RemoveAt(Remove);
                Lbx_Player.Items.Clear();
                foreach(Player b in ChooseTeam.players)
                {
                    Lbx_Player.Items.Add("[" + b.playernumber + "] " + b.playername + ", " + b.playerposition);
                }
            }
            else
            {
                MessageBox.Show("There are less than 11 number of Players", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
