﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace AppDev_Takehome_W04
{
    internal class Team
    {

        private string TeamName;
        private string TeamCountry;
        private string TeamCity;
        private List<Player> Player;


        public Team(string TeamName, string TeamCountry, string TeamCity, List<Player> Player)
        {
            this.TeamName = TeamName;
            this.TeamCountry = TeamCountry;
            this.TeamCity = TeamCity;
            this.Player = Player;
        }

        public string teamname { get => TeamName; set => TeamName = value; }
        public string teamcountry { get => TeamCountry; set => TeamCountry = value; }
        public string teamcity { get => TeamCity; set => TeamCity = value; }
        internal List<Player> players { get => Player; set => Player = value; }

    }
}