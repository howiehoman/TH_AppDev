﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDev_Takehome_W04
{
    internal class Player
    {
        private string PlayerNumber;
        private string PlayerName;
        private string PlayerPosition;

        public Player(string PlayerNumber, string PlayerName, string PlayerPosition)
        {
            this.PlayerNumber = PlayerNumber;
            this.PlayerName = PlayerName;
            this.PlayerPosition = PlayerPosition;
        }
        public string playernumber { get => PlayerNumber; set => PlayerNumber = value; }
        public string playername { get => PlayerName; set => PlayerName = value; }
        public string playerposition { get => PlayerName; set => PlayerName = value; }
    }
}
