﻿namespace AppDev_Takehome_W04
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Lbl_SoccerTeamList = new Label();
            Lbl_ChooseCountry = new Label();
            Lbl_ChooseTeam = new Label();
            Lbl_AddingTeam = new Label();
            Lbl_AddingPlayers = new Label();
            Cobx_ChooseCountry = new ComboBox();
            Cobx_ChooseTeam = new ComboBox();
            Lbl_TeamName = new Label();
            Lbl_TeamCountry = new Label();
            Lbl_TeamCity = new Label();
            Tbx_TeamName = new TextBox();
            Tbx_TeamCountry = new TextBox();
            Tbx_TeamCity = new TextBox();
            Lbl_PlayerName = new Label();
            Lbl_PlayerPosition = new Label();
            Lbl_PlayerNumber = new Label();
            Tbx_PlayerName = new TextBox();
            Tbx_PlayerNumber = new TextBox();
            Btn_AddTeam = new Button();
            Btn_AddPlayer = new Button();
            Lbx_Player = new ListBox();
            Btn_Remove = new Button();
            bindingSource1 = new BindingSource(components);
            Cobx_PlayerPosition = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            SuspendLayout();
            // 
            // Lbl_SoccerTeamList
            // 
            Lbl_SoccerTeamList.AutoSize = true;
            Lbl_SoccerTeamList.Font = new Font("Segoe UI", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Lbl_SoccerTeamList.Location = new Point(12, 47);
            Lbl_SoccerTeamList.Name = "Lbl_SoccerTeamList";
            Lbl_SoccerTeamList.Size = new Size(226, 40);
            Lbl_SoccerTeamList.TabIndex = 0;
            Lbl_SoccerTeamList.Text = "Soccer Team List";
            // 
            // Lbl_ChooseCountry
            // 
            Lbl_ChooseCountry.AutoSize = true;
            Lbl_ChooseCountry.Location = new Point(12, 102);
            Lbl_ChooseCountry.Name = "Lbl_ChooseCountry";
            Lbl_ChooseCountry.Size = new Size(191, 32);
            Lbl_ChooseCountry.TabIndex = 1;
            Lbl_ChooseCountry.Text = "Choose Country:";
            // 
            // Lbl_ChooseTeam
            // 
            Lbl_ChooseTeam.AutoSize = true;
            Lbl_ChooseTeam.Location = new Point(12, 147);
            Lbl_ChooseTeam.Name = "Lbl_ChooseTeam";
            Lbl_ChooseTeam.Size = new Size(163, 32);
            Lbl_ChooseTeam.TabIndex = 2;
            Lbl_ChooseTeam.Text = "Choose Team:";
            // 
            // Lbl_AddingTeam
            // 
            Lbl_AddingTeam.AutoSize = true;
            Lbl_AddingTeam.Font = new Font("Segoe UI", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Lbl_AddingTeam.Location = new Point(462, 47);
            Lbl_AddingTeam.Name = "Lbl_AddingTeam";
            Lbl_AddingTeam.Size = new Size(185, 40);
            Lbl_AddingTeam.TabIndex = 3;
            Lbl_AddingTeam.Text = "Adding Team";
            // 
            // Lbl_AddingPlayers
            // 
            Lbl_AddingPlayers.AutoSize = true;
            Lbl_AddingPlayers.Font = new Font("Segoe UI", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Lbl_AddingPlayers.Location = new Point(841, 47);
            Lbl_AddingPlayers.Name = "Lbl_AddingPlayers";
            Lbl_AddingPlayers.Size = new Size(207, 40);
            Lbl_AddingPlayers.TabIndex = 4;
            Lbl_AddingPlayers.Text = "Adding Players";
            // 
            // Cobx_ChooseCountry
            // 
            Cobx_ChooseCountry.FormattingEnabled = true;
            Cobx_ChooseCountry.Location = new Point(209, 102);
            Cobx_ChooseCountry.Name = "Cobx_ChooseCountry";
            Cobx_ChooseCountry.Size = new Size(242, 40);
            Cobx_ChooseCountry.TabIndex = 5;
            Cobx_ChooseCountry.SelectedIndexChanged += Cobx_ChooseCountry_SelectedIndexChanged;
            // 
            // Cobx_ChooseTeam
            // 
            Cobx_ChooseTeam.FormattingEnabled = true;
            Cobx_ChooseTeam.Location = new Point(209, 148);
            Cobx_ChooseTeam.Name = "Cobx_ChooseTeam";
            Cobx_ChooseTeam.Size = new Size(242, 40);
            Cobx_ChooseTeam.TabIndex = 6;
            Cobx_ChooseTeam.SelectedIndexChanged += Cobx_ChooseTeam_SelectedIndexChanged;
            // 
            // Lbl_TeamName
            // 
            Lbl_TeamName.AutoSize = true;
            Lbl_TeamName.Location = new Point(462, 102);
            Lbl_TeamName.Name = "Lbl_TeamName";
            Lbl_TeamName.Size = new Size(147, 32);
            Lbl_TeamName.TabIndex = 7;
            Lbl_TeamName.Text = "Team Name:";
            // 
            // Lbl_TeamCountry
            // 
            Lbl_TeamCountry.AutoSize = true;
            Lbl_TeamCountry.Location = new Point(462, 147);
            Lbl_TeamCountry.Name = "Lbl_TeamCountry";
            Lbl_TeamCountry.Size = new Size(168, 32);
            Lbl_TeamCountry.TabIndex = 8;
            Lbl_TeamCountry.Text = "Team Country:";
            // 
            // Lbl_TeamCity
            // 
            Lbl_TeamCity.AutoSize = true;
            Lbl_TeamCity.Location = new Point(462, 193);
            Lbl_TeamCity.Name = "Lbl_TeamCity";
            Lbl_TeamCity.Size = new Size(124, 32);
            Lbl_TeamCity.TabIndex = 9;
            Lbl_TeamCity.Text = "Team City:";
            // 
            // Tbx_TeamName
            // 
            Tbx_TeamName.Location = new Point(629, 99);
            Tbx_TeamName.Name = "Tbx_TeamName";
            Tbx_TeamName.Size = new Size(200, 39);
            Tbx_TeamName.TabIndex = 10;
            // 
            // Tbx_TeamCountry
            // 
            Tbx_TeamCountry.Location = new Point(629, 149);
            Tbx_TeamCountry.Name = "Tbx_TeamCountry";
            Tbx_TeamCountry.Size = new Size(200, 39);
            Tbx_TeamCountry.TabIndex = 11;
            // 
            // Tbx_TeamCity
            // 
            Tbx_TeamCity.Location = new Point(629, 194);
            Tbx_TeamCity.Name = "Tbx_TeamCity";
            Tbx_TeamCity.Size = new Size(200, 39);
            Tbx_TeamCity.TabIndex = 12;
            // 
            // Lbl_PlayerName
            // 
            Lbl_PlayerName.AutoSize = true;
            Lbl_PlayerName.Location = new Point(841, 102);
            Lbl_PlayerName.Name = "Lbl_PlayerName";
            Lbl_PlayerName.Size = new Size(154, 32);
            Lbl_PlayerName.TabIndex = 13;
            Lbl_PlayerName.Text = "Player Name:";
            // 
            // Lbl_PlayerPosition
            // 
            Lbl_PlayerPosition.AutoSize = true;
            Lbl_PlayerPosition.Location = new Point(841, 193);
            Lbl_PlayerPosition.Name = "Lbl_PlayerPosition";
            Lbl_PlayerPosition.Size = new Size(174, 32);
            Lbl_PlayerPosition.TabIndex = 14;
            Lbl_PlayerPosition.Text = "Player Position:";
            // 
            // Lbl_PlayerNumber
            // 
            Lbl_PlayerNumber.AutoSize = true;
            Lbl_PlayerNumber.Location = new Point(841, 147);
            Lbl_PlayerNumber.Name = "Lbl_PlayerNumber";
            Lbl_PlayerNumber.Size = new Size(178, 32);
            Lbl_PlayerNumber.TabIndex = 15;
            Lbl_PlayerNumber.Text = "Player Number:";
            // 
            // Tbx_PlayerName
            // 
            Tbx_PlayerName.Location = new Point(1024, 99);
            Tbx_PlayerName.Name = "Tbx_PlayerName";
            Tbx_PlayerName.Size = new Size(200, 39);
            Tbx_PlayerName.TabIndex = 16;
            // 
            // Tbx_PlayerNumber
            // 
            Tbx_PlayerNumber.Location = new Point(1024, 149);
            Tbx_PlayerNumber.Name = "Tbx_PlayerNumber";
            Tbx_PlayerNumber.Size = new Size(200, 39);
            Tbx_PlayerNumber.TabIndex = 17;
            // 
            // Btn_AddTeam
            // 
            Btn_AddTeam.Location = new Point(629, 257);
            Btn_AddTeam.Name = "Btn_AddTeam";
            Btn_AddTeam.Size = new Size(150, 46);
            Btn_AddTeam.TabIndex = 19;
            Btn_AddTeam.Text = "Add";
            Btn_AddTeam.UseVisualStyleBackColor = true;
            Btn_AddTeam.Click += Btn_AddTeam_Click;
            // 
            // Btn_AddPlayer
            // 
            Btn_AddPlayer.Location = new Point(1024, 257);
            Btn_AddPlayer.Name = "Btn_AddPlayer";
            Btn_AddPlayer.Size = new Size(150, 46);
            Btn_AddPlayer.TabIndex = 20;
            Btn_AddPlayer.Text = "Add";
            Btn_AddPlayer.UseVisualStyleBackColor = true;
            Btn_AddPlayer.Click += Btn_AddPlayer_Click;
            // 
            // Lbx_Player
            // 
            Lbx_Player.FormattingEnabled = true;
            Lbx_Player.Location = new Point(12, 241);
            Lbx_Player.Name = "Lbx_Player";
            Lbx_Player.Size = new Size(453, 228);
            Lbx_Player.TabIndex = 21;
            // 
            // Btn_Remove
            // 
            Btn_Remove.Location = new Point(12, 486);
            Btn_Remove.Name = "Btn_Remove";
            Btn_Remove.Size = new Size(150, 46);
            Btn_Remove.TabIndex = 22;
            Btn_Remove.Text = "Remove";
            Btn_Remove.UseVisualStyleBackColor = true;
            Btn_Remove.Click += Btn_Remove_Click;
            // 
            // Cobx_PlayerPosition
            // 
            Cobx_PlayerPosition.FormattingEnabled = true;
            Cobx_PlayerPosition.Location = new Point(1024, 193);
            Cobx_PlayerPosition.Name = "Cobx_PlayerPosition";
            Cobx_PlayerPosition.Size = new Size(200, 40);
            Cobx_PlayerPosition.TabIndex = 23;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1236, 544);
            Controls.Add(Cobx_PlayerPosition);
            Controls.Add(Btn_Remove);
            Controls.Add(Lbx_Player);
            Controls.Add(Btn_AddPlayer);
            Controls.Add(Btn_AddTeam);
            Controls.Add(Tbx_PlayerNumber);
            Controls.Add(Tbx_PlayerName);
            Controls.Add(Lbl_PlayerNumber);
            Controls.Add(Lbl_PlayerPosition);
            Controls.Add(Lbl_PlayerName);
            Controls.Add(Tbx_TeamCity);
            Controls.Add(Tbx_TeamCountry);
            Controls.Add(Tbx_TeamName);
            Controls.Add(Lbl_TeamCity);
            Controls.Add(Lbl_TeamCountry);
            Controls.Add(Lbl_TeamName);
            Controls.Add(Cobx_ChooseTeam);
            Controls.Add(Cobx_ChooseCountry);
            Controls.Add(Lbl_AddingPlayers);
            Controls.Add(Lbl_AddingTeam);
            Controls.Add(Lbl_ChooseTeam);
            Controls.Add(Lbl_ChooseCountry);
            Controls.Add(Lbl_SoccerTeamList);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Lbl_SoccerTeamList;
        private Label Lbl_ChooseCountry;
        private Label Lbl_ChooseTeam;
        private Label Lbl_AddingTeam;
        private Label Lbl_AddingPlayers;
        private ComboBox Cobx_ChooseCountry;
        private ComboBox Cobx_ChooseTeam;
        private Label Lbl_TeamName;
        private Label Lbl_TeamCountry;
        private Label Lbl_TeamCity;
        private TextBox Tbx_TeamName;
        private TextBox Tbx_TeamCountry;
        private TextBox Tbx_TeamCity;
        private Label Lbl_PlayerName;
        private Label Lbl_PlayerPosition;
        private Label Lbl_PlayerNumber;
        private TextBox Tbx_PlayerName;
        private TextBox Tbx_PlayerNumber;
        private Button Btn_AddTeam;
        private Button Btn_AddPlayer;
        private ListBox Lbx_Player;
        private Button Btn_Remove;
        private BindingSource bindingSource1;
        private ComboBox Cobx_PlayerPosition;
    }
}
